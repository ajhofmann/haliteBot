from hlt import *
from networking import *

myID, gameMap = getInit()
sendInit("1stPythonBot")

def normalize(x):
    mini = min(x)
    maxi = max(x)
    if (maxi-mini) != 0: return [(i-mini)/(maxi-mini) for i in x]
    return x

def getFilledPosns(myPosns, OccupiedPosns, gameMap):
    for y in range(gameMap.height):
        for x in range(gameMap.width):
            currentSite = gameMap.getSite(Location(x, y))
            if currentSite.owner == myID:
                myPosns.append([Location(x, y), currentSite])
            elif currentSite.owner != 0:
                OccupiedPosns.append([Location(x, y), currentSite])


# get's an overall feel of where opponenets are
# returns an array of directions from "safest" to
# most "dangerous"
def preferredDirs(posn, OccupiedPosns, gameMap):
    pi = 3.141592
    # break all angles into 4 quadrants,
    # pick one with low variance and far distance
    avgs = [0,0,0,0] # mean
    vari = [0,0,0,0] # variance
    counts = [0,0,0,0] # absolute count
    strengths = [0,0,0,0]
    for enemy in OccupiedPosns:
        curAng = gameMap.getAngle(posn[0], enemy[0])
        curDis = gameMap.getDistance(posn[0], enemy[0])
        streng = enemy[1].strength
        dirToInc = 2 # 1 : N, 2 : E, 3 : S, 4 : W
        if(curAng >= 0):
            if(curAng > 3*pi/4):
                dirToInc = 4 # West
            if(curAng > pi/4):
                dirToInc = 1 # North
        elif(curAng < -3*pi/4):
            dirToInc = 4 # West
        elif(curAng < -1*pi/4):
            dirToInc = 3 # South
        
        avgs[dirToInc-1] += curDis
        vari[dirToInc-1] += (curDis)**2
        strengths[dirToInc-1] += streng
        counts[dirToInc-1] += 1

    for i in range(4): # get actual variance
        if(counts[i] != 0): avgs[i] /= counts[i]
        vari[i] = vari[i] - avgs[i]*avgs[i]

    avgs = normalize(avgs) # High average distance
    vari = normalize(list(map(lambda x: x**-1 if x != 0 else 0, vari))) # prefer low variance
    counts = normalize(list(map(lambda x: x**-1 if x != 0 else 0, counts))) # prefer low count
    strengths = normalize(list(map(lambda x: x**-1 if x != 0 else 0, strengths)))  # prefer low strength
    sumUp = [a + b + c + d for a, b, c, d in zip(avgs, vari, counts, strengths)]


    return sumUp

        
    

def pickDir(posn, preferred, gameMap):
    # array of surrounding sites
    surrounding = []
    for i in range(1,5):
        surrounding.append(gameMap.getSite(posn[0], i))
    


while True:
    moves = []
    myPosns = []
    OccupiedPosns = []
    gameMap = getFrame()

    # get's us an array of all my posns and all opponents
    getFilledPosns(myPosns, OccupiedPosns, gameMap)

    # get's a feel for where enemies are on the board
    preferred = preferredDirs(myPosns[len(myPosns)//2], OccupiedPosns, gameMap)

    # rankings
    prefer = []
    for i in range(4):
        sortedSum = sorted(preferred)
        prefer.append(preferred.index(sortedSum[i])+1)

    for posn in myPosns:
        added = False
        for dir in prefer:
            if (gameMap.getSite(posn[0], dir).owner != myID and
                        gameMap.getSite(posn[0], dir).strength < posn[1].strength):
                moves.append(Move(posn[0], dir))
                added = True
                break

        if (not added):
            if(gameMap.getSite(posn[0], prefer[0]).owner == myID):
                moves.append(Move(posn[0], prefer[0]))
            else:
                moves.append(Move(posn[0], 0))


    sendFrame(moves)
