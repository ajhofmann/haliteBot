from hlt import *
from networking import *

myID, gameMap = getInit()
sendInit("1stPythonBot")

def normalize(x):
    mini = min(x)
    maxi = max(x)
    if (maxi-mini) != 0: return [(i-mini)/(maxi-mini) for i in x]
    return x

def isEdge(posn, gameMap):
    directions = [1,2,3,4]
    for dir in directions:
        if(gameMap.getSite(posn[0], dir).owner != myID):
            return True
    return False

def getFilledPosns(edges, centers, OccupiedPosns, gameMap):
    for y in range(gameMap.height):
        for x in range(gameMap.width):
            currentSite = gameMap.getSite(Location(x, y))
            if currentSite.owner == myID:
                posn = [Location(x, y), currentSite]
                if(isEdge(posn, gameMap)):
                    edges.append([Location(x, y), currentSite])
                else:
                    centers.append([Location(x, y), currentSite])
            elif currentSite.owner != 0:
                OccupiedPosns.append([Location(x, y), currentSite])


# get's an overall feel of where opponenets are
# returns an array of directions from "safest" to
# most "dangerous"
def preferredDirs(posn, OccupiedPosns, gameMap):
    pi = 3.141592
    # break all angles into 4 quadrants,
    # pick one with low variance and far distance
    avgs = [0,0,0,0] # mean
    vari = [0,0,0,0] # variance
    counts = [0,0,0,0] # absolute count
    strengths = [0,0,0,0]
    for enemy in OccupiedPosns:
        curAng = gameMap.getAngle(posn[0], enemy[0])
        curDis = gameMap.getDistance(posn[0], enemy[0])
        streng = enemy[1].strength
        dirToInc = 2 # 1 : N, 2 : E, 3 : S, 4 : W
        if(curAng >= 0):
            if(curAng > 3*pi/4):
                dirToInc = 4 # West
            if(curAng > pi/4):
                dirToInc = 1 # North
        elif(curAng < -3*pi/4):
            dirToInc = 4 # West
        elif(curAng < -1*pi/4):
            dirToInc = 3 # South
        
        avgs[dirToInc-1] += curDis
        vari[dirToInc-1] += (curDis)**2
        strengths[dirToInc-1] += streng
        counts[dirToInc-1] += 1

    for i in range(4): # get actual variance
        if(counts[i] != 0): avgs[i] /= counts[i]
        vari[i] = vari[i] - avgs[i]*avgs[i]

    avgs = normalize(avgs) # High average distance
    vari = normalize(list(map(lambda x: x**-1 if x != 0 else 0, vari))) # prefer low variance
    counts = normalize(list(map(lambda x: x**-1 if x != 0 else 0, counts))) # prefer low count
    strengths = normalize(list(map(lambda x: x**-1 if x != 0 else 0, strengths)))  # prefer low strength
    sumUp = [a + b + c + d for a, b, c, d in zip(avgs, vari, counts, strengths)]


    return sumUp

# keep track of where the center pieces were going so they don't go back and forth
lastCenterMove = {}

while True:
    moves = []
    edges = []
    centers = []
    OccupiedPosns = []
    gameMap = getFrame()

    # get's us an array of all my posns and all opponents
    getFilledPosns(edges, centers, OccupiedPosns, gameMap)

    # for edges try to expand to the most worthwhile open space
    for posn in edges:
        if(posn[1].strength != 0):
            values = []
            strengths = []
            for i in range(1, 5):
                if(gameMap.getSite(posn[0], i).owner == myID):
                    values.append(10000000)
                    strengths.append(100000)
                else:
                    strengths.append(gameMap.getSite(posn[0], i).strength)
                    if(gameMap.getSite(posn[0], i).production != 0):
                        values.append(gameMap.getSite(posn[0], i).strength / gameMap.getSite(posn[0], i).production)

            dir = values.index(min(values))
            if(strengths[dir] < posn[1].strength):
                moves.append(Move(posn[0], dir+1))
            else:
                moves.append(Move(posn[0], 0))

    #move centers to closest edge
    for posn in centers:
        if(posn[1].strength != 0):
            pi = 3.141592
            closestEdge = 0
            minDis = 10000
            for target in edges:
                curDis = gameMap.getDistance(posn[0], target[0])
                if(curDis < minDis):
                    minDis = curDis
                    closestEdge = target

            curAng = gameMap.getAngle(posn[0], closestEdge[0])
            #with open("test.txt", "a") as myfile:
            #    myfile.write(str(posn[0].x) + " " + str(posn[0].y) + " ")
            #    myfile.write(str(closestEdge[0].x) + " " + str(closestEdge[0].y) + " ")
            #    myfile.write(str(curAng) + " ")
            dirToMove = 2 # default East
            if(curAng >= 0):
                if(curAng > 3*pi/4):
                    dirToMove = 4 # West
                elif(curAng > pi/4):
                    dirToMove = 1 # North
            elif(curAng < -3*pi/4):
                dirToMove = 4 # West
            elif(curAng < -1*pi/4):
                dirToMove = 3 # South

          #  with open("test.txt", "a") as myfile:
           #     myfile.write(str(dirToMove) + "\n ")
            moves.append(Move(posn[0], dirToMove))



    sendFrame(moves)
